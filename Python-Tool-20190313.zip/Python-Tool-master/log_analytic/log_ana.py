import os

# where .py is
py_path = os.path.dirname(os.path.realpath(__file__))

# output file path
output_1 = os.path.join(py_path,"log_1.txt")
output_2 = os.path.join(py_path,"log_2.txt")
output_3 = os.path.join(py_path,"log_3.txt")
output_4 = os.path.join(py_path,"log_4.txt")

# pos = location_xyz(GPS) + AHRS(ATT) 
count_million = 0
compare = 0 
GPS_xyz = ', 0, 0, 0'
GPS_time = 0
GPS_dop  = 0
ATT_time = 0
for item in os.listdir(py_path):
    if item.endswith('log'):
        file = os.path.join(py_path,item)
        print('OPEN: '+ file)

        ## start to process .log
        with open(file,'r') as log:
            with open(output_1,'a') as out_1:
                with open(output_2,'a') as out_2:
                    with open(output_3,'a') as out_3:
                        with open(output_4,'a') as out_4:
                            ## init a format msg in txt 
                            out_1.write('TimeUS,Roll(deg),Pitch(deg),Yaw(deg),AcX(m/s/s),AcY(m/s/s),AcZ(m/s/s),Lat,Lon,Alt,HDop(0~100,>3 bad)\n')
                            
                            ## i = a single line in log 
                            for i in log.readlines():
                                if i[0:3] =='FMT':
                                    if i[14:18] == 'GPS,':
                                        pass
                                        #out.write(i[14:18]+i[34:])
                                    elif i[14:18] == 'ATT,':
                                        pass
                                        #out.write(i[14:18]+i[34:])
                                    elif i[14:18] == 'IMU,':
                                        pass
                                        #out.write(i[14:18]+i[34:])
                                ## meet ATT
                                elif i[0:3] == 'ATT':
                                    count = 0
                                    for j in range(0,len(i)):
                                        if i[j] == ',':
                                            count+=1
                                            if count   == 1:
                                                col_1 = j
                                            elif count == 2:
                                                col_2 = j
                                                ATT_time = i[col_1+2:col_2]
                                                #print('ATT:'+ATT_time)
                                            elif count == 8:
                                                col_8 = j
                                                ATT_msg = i[5:col_8]
                                                if int(ATT_time) > int(GPS_time) and GPS_xyz != ', 0, 0, 0':
                                                    #print(ATT_msg+GPS_xyz)
                                                    #out.write(ATT_msg+GPS_xyz+'\n')
                                                    if count_million   < 500001:
                                                        out_1.write(ATT_msg+GPS_xyz+'\n')
                                                        count_million+=1
                                                    elif count_million < 1000001 :
                                                        #out_2.write(ATT_msg+GPS_xyz+'\n')
                                                        count_million+=1
                                                        print(output[:-4]+'_2'+output[-4:])
                                                    elif count_million < 1500001:
                                                        out_3.write(ATT_msg+GPS_xyz+'\n')
                                                        count_million+=1
                                                        print(output[:-4]+'_3'+output[-4:])
                                                    elif count_million < 2000001:
                                                        out_4.write(ATT_msg+GPS_xyz+'\n')
                                                        count_million+=1
                                                        #print(output[:-4]+'_3'+output[-4:])
                                                
                                                    
                                elif i[0:4] == 'IMU,':
                                    pass
                                    #print(i[:14])
                                    #out.write(i)
                                elif i[0:4] == 'IMU2':
                                    pass
                                    #print(i[:15])
                                    #out.write(i)
                                elif i[0:3] == 'GPS':
                                    #print(i[:16]+i[46:77])
                                    count = 0
                                    for j in range(0,len(i)):
                                        if i[j] == ',':
                                            count+=1
                                            if count   == 1:
                                                col_1 = j
                                                #print(i[:col_1])
                                            elif count == 2:
                                                col_2 = j
                                                GPS_time = i[col_1+2:col_2]
                                                #print('GPS:'+GPS_time)
                                            elif count == 6:
                                                col_6 = j
                                            elif count == 7:
                                                col_7 = j
                                                GPS_dop = i[col_6:col_7]
                                            elif count == 10:
                                                col_10 = j
                                                #if float(GPS_dop) < 6 :
                                                GPS_xyz = i[col_7:col_10]
                                                GPS_xyz = GPS_xyz + GPS_dop
                                                #temp = GPS_xyz
                                            # elif count == 8:
                                                # print(i[13:j+1])
                                                #out.write(i)
for item in os.listdir(py_path):
    item = os.path.join(py_path,item)
    if os.path.getsize(item) == 0:
        os.remove(item)
print('Done!')
