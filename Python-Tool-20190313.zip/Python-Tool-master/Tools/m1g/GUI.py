#!/usr/bin/python3
from tkinter import *
from tkinter import messagebox
import m1g

window = Tk()
window.geometry("600x400")
window.title('M1G GUI')

def helloCallBack():
    msg = messagebox.showinfo( "TEST", "GUI Working") 

def quit():
    window.destroy()

reboot = Button(window, text = "reboot", command = m1g.m1g_reboot)
reboot.place(x = 30,y = 130)

test = Button(window, text = "GUI TEST", command = helloCallBack)
test.place(x = 30,y = 30)

quit = Button(window, text = "GUI QUIT", command = quit)
quit.place(x = 30,y = 80)

start = Button(window, text = "start", command = m1g.m1g_start)
start.place(x = 30,y = 180)

stop = Button(window, text = "stop", command = m1g.m1g_stop)
stop.place(x = 30,y = 230)

m1g_test = Button(window, text = "m1g_test", command = m1g.m1g_test)
m1g_test.place(x = 150,y = 130)

m1g_ftp_unix = Button(window, text = "ftp_unix", command = m1g.m1g_ftp_unix)
m1g_ftp_unix.place(x = 150,y = 30)

m1g_ftp_win = Button(window, text = "ftp_win", command = m1g.m1g_ftp_win)
m1g_ftp_win.place(x = 150,y = 80)

m1g_line = Button(window, text = "m1g_line", command = m1g.m1g_line)
m1g_line.place(x = 150,y = 180)

window.mainloop()
