import PhotoScan as ps


def main():

    print("Script started")
    doc = ps.app.document
    chunk = PhotoScan.Chunk
    chunk.label = "New Chunk"
    
    doc.save(r'C:\Users\rslab142\Desktop\1234.psz')
    print('OK')
    
main()
