#!/usr/bin/python3
import shutil, pathlib, os
from tkinter import *
from tkinter import messagebox
from tkinter.filedialog import *
from dirsync import sync

title_bar = '同步處理工具'

window = Tk()
window.geometry("400x25")
window.title(title_bar)
#window.withdraw()



fuc_title = { '1':'目的資料夾',
              '2':'目的資料夾',
              '3':'同步處理',
              '4':'dirs',
              '5':'空',
              '6':'結束',
              '7':'空',
              '8':'空',
              '9':'空',
              '10':'結束'}

src_dst = []

def src():
    src_name = askdirectory()
    src_dst.append(src_name) 
    print(src_dst[0])
    return src_name

def dst():
    dst_name = askdirectory()
    src_dst.append(dst_name)
    print(src_dst[1])
    return dst_name
    

def sync_dir():
    sync(src(), dst(), 'sync')
    print('sync done.')
    os.system('exit')

# def sync_dir():
    # sync(askdirectory(), askdirectory(), 'sync')
    # print('sync done.')
    
def print_dir():
    print(src_dst[0], src_dst[0])
    
def quit():
    window.destroy()


line_1 = 0
line_2 = 100

length = 13
height = 1

fuc_1  = Button(window, width = length, height = height, text = fuc_title['1'], command = src ).place(x = 0  ,y = line_1)

fuc_2  = Button(window, width = length, height = height, text = fuc_title['2'], command = dst ).place(x = 100,y = line_1)

fuc_3  = Button(window, width = length, height = height, text = fuc_title['3'], command = sync_dir).place(x = 200,y = line_1)

fuc_6  = Button(window, width = length, height = height, text = fuc_title['6'], command = quit).place(x = 300,y = line_1)


window.mainloop()
