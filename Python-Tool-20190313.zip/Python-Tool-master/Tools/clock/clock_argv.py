#!/usr/bin/env python3
import sys, os, time, datetime
import random, smtplib, requests

rand = random.randint(600,2200)
min = int(rand/60)
sec = rand%60

exe_time = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")

url   = 'http://eadm.ncku.edu.tw/welldoc/ncku/iftwd/doSignIn.php'

check = {"Content-Type":"application/json","data":{"fn":"list","psnCode":"10502065","password":"10502065"}}

on    = {"Content-Type":"application/json","data":{"fn":"signIn","mtime":"A","psnCode":"10502065","password":"10502065",}}

off   = {"Content-Type":"application/json","data":{"fn":"signIn","mtime":"D","psnCode":"10502065","password":"10502065",}}

#----------------------------------------------------------------------------------------------------------------------------
def clock_in(state):
    res = requests.post(url, json = state)
    return print(res.text)

def send_mail():
	gmail_sender = 'kakinglin@gmail.com'
	gmail_passwd = 'bpvfswzcogzdvtil'
	
	TO = 'kakinglin@gmail.com'
	SUBJECT = 'INFORM MAIL'
	TEXT = '[ ' + option + ' ]' + '\t Execute at : '+ exe_time + '\n'

	BODY = '\r\n'.join(['To: %s' % TO, 'From: %s' % gmail_sender, 'Subject: %s' % SUBJECT, '', TEXT])
	server = smtplib.SMTP('smtp.gmail.com', 587)
	server.ehlo()
	server.starttls()
	server.login(gmail_sender, gmail_passwd)
	
	
	try:
		server.sendmail(gmail_sender, [TO], BODY)
		print ('email sent')
	except:
		print ('error sending mail')

	server.quit()
	
#----------------------------------------------------------------------------------------------------------------------------

if len(sys.argv) < 2:
    print('No argument')
    sys.exit()

if sys.argv[1].startswith('--'):
    option = sys.argv[1][2:]
    if option == 'on':
        time.sleep(rand)
        clock_in(on)
    elif option == 'off':
        time.sleep(rand)
        clock_in(off)
    elif option == 'check':
        clock_in(check)
    else:
        print('[--on] [--off] [--check]')
        sys.exit()
else:
	print('wrong type argv')
	sys.exit()

	
#send_mail()
