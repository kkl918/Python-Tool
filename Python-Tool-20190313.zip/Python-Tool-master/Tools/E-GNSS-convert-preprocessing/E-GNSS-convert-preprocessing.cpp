#include <sys/types.h>
#include <dirent.h>
#include <errno.h>
#include <vector>
#include <string>
#include<iostream>
#include<fstream>
using namespace std;

int getdir(string dir, vector<string> &files);

int main(){
    string str;
    char ch, buf[102400];
	int  no_use[1024];
	int  j=0,k=0,m=0,n=0,comma=0, num_line=0, bufp=0,no_use_p=0;
	//int j=0,k=0,m=0,n=0,comma=0, num_line=0, bufp=0,no_use_p=0;
	
	
	//Ū���۹���|��Ƨ��ɮצW�� 
	string dir = string(".");//��Ƨ����|(�����}or�۹��})
    vector<string> files = vector<string>();
    getdir(dir, files);
    
    
    for(int i=2; i<files.size()-1; i++){
    //for(int i=2; i<5; i++){
			 
		ifstream ifs;
		ifs.open(files[i].c_str());
		
		//���L�ɦW 
		if(ifs){
		    cout << files[i] <<endl;
		}

		
		// .dat -> .txt 
		str = files[i].replace(files[i].length()-4, files[i].length(), ".txt");
		ofstream Result(str.c_str());
	
	    // Ū���ɮ׼g�J�}�C 
		while((ch = ifs.get()) != EOF){
		 if(ch ==','){
			comma++;
			if(comma == 1){
			 buf[bufp++] = ',';
			 buf[bufp++] = 'N';
			 buf[bufp++] = 'E';
			 buf[bufp++] = 'h';
			 buf[bufp++] = ',';
			} 
			 
		    else if(comma == 4)
			 comma = 0;
			else
			 buf[bufp++] = ch;
		 }else	 
			 buf[bufp++] = ch; 
        } 
        
        //cout << &buf[0] << endl;
        
        //���ڤ��n���F���m 
        while(buf[k++] != '\0' ){
	     if(buf[k] =='\n'){
			m = no_use[no_use_p++] = k-1;
			//cout << buf[m] << " ";
		 }
	 
        }

        //��ڼg�J 
        while(buf[j]!='\0'){
    	 if( j == no_use[n]){
    		buf[++j];
    		n++;
		 }else
		  Result << buf[j++];
	    }
		ifs.close();
		Result.close();	
     }
   
   system("pause");
}

int getdir(string dir, vector<string> &files){
    DIR *dp;//�Х߸�Ƨ�����
    struct dirent *dirp;
    if((dp = opendir(dir.c_str())) == NULL){
        cout << "Error(" << errno << ") opening " << dir << endl;
        return errno;
    }
    while((dirp = readdir(dp)) != NULL){//�p�Gdirent���ЫD��
        files.push_back(string(dirp->d_name));//�N��Ƨ��M�ɮצW��Jvector
    }
    closedir(dp);//������Ƨ�����
    return 0;
}
