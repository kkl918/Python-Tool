import os

folder = [r'C:\Users\kakin\Desktop\NCKU\燃燒_report\500disel\new',
          r'C:\Users\kakin\Desktop\NCKU\燃燒_report\500n\new',
          r'C:\Users\kakin\Desktop\NCKU\燃燒_report\600n\new']
          
for i in folder:
    os.chdir(i) 
    for item in os.listdir(i):
        if item[-5] == '_':
            new_name = item[:-5]+item[-4:]
            os.rename(item, new_name)
            print(item, new_name)
    print('\n')