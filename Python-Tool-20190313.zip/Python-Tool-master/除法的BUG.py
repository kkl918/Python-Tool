for i in range(0,10):

    t=i*0.1
    
    j=t%0.5
    print(j)
