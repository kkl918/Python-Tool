import pandas as pd

df = pd.DataFrame({'key1':['A','B','C','B','B','A','D','E'],
                   'key2':['A','B','D','B','D','A','C','D'],
				   'count1':[10 ,20 ,23 ,42 ,51 ,76 ,65 ,80],
				   'count2':[1.2,3.4,4.5,7.4,4.4,5.5,3.4,1.2]})
print(df)
print('\n')
print(df.groupby('key1').mean())
print(df.groupby('key1').sum())
print(df.groupby(['key1','key2']).mean())
print(df.groupby(['key1','key2']).size())
print(df.groupby(['key1','key2'])[['count1']].mean())
