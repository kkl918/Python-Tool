
# coding: utf-8

# In[3]:

f = open('tesco.csv','r')


# In[4]:

print(f.read())


# In[7]:

# ! is refer to execute command line in system(not in ipython shell)
# % is refer to excute in ipython shell, but ! means excute in system
# -f means file, put file name(in same folder) or put path.
# -s means support   threshold is 0.3(minimun)
# -c means cinfident threshold is 0.5
get_ipython().system('python3 apriori.py -f tesco.csv -s 0.3 -c 0.5')


# In[ ]:


