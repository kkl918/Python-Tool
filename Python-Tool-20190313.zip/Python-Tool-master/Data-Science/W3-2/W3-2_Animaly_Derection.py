import pandas  	  	  as pd
import matplotlib.pyplot  as plt
import numpy              as np
from   scipy.stats.mstats import mquantiles

%matplotlib inline

x = np.random.randn(1000)
r = plt.boxplot(x,showfliers=True) #show outlines
plt.show()

#print(r)

print('Anomaly:',r['fliers'][0].get_data()[1])

print('quntiles', mquantiles(x))

IQR = mquantiles(x)[2]- mquantiles(x)[0] # q3 -q1

print('IQR:',IQR)

maximun = mquantiles(x)[2] + 1.5 * IQR
minimun = mquantiles(x)[2] - 1.5 * IQR

print('Max:', maximun, '\nMin:', minimun)

print('----------------------------')

print('pandas:')

df = pd.DataFrame({'x':x})
df.plot(kind='kde', title='PDF')
#print(df.plot(kind='kde', title='PDF'))
