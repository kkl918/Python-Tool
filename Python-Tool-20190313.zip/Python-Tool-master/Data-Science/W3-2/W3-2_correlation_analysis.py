# coding: utf-8

# In[1]:

import pandas as pd
import numpy  as np
import matplotlib.pyplot as plt

get_ipython().magic('matplotlib inline')

plt.rcParams['font.family']='SimHei' #display chinese

# Goverment open data platform - Real estate price data(http://data.gov.tw/node/6213)
# extension name .csv -> .CSV, should be upper case or error
df = pd.read_csv('A_LVR_LAND_A.CSV', encoding ='big5')
df[:10]

df.corr()

plt.rcParams['axes.unicode_minus']=False
df.plot(kind='scatter',title='spread_chart(high +corr)',figsize=(6,4),x='Price',y='Total_area(m^2)',marker='+')


# In[2]:

df.plot(kind='scatter',title='spread_chart(high +corr)',figsize=(6,4),x='Rooms',y='Bath room',marker='+')


# In[3]:

df.plot(kind='scatter',title='spread_chart(high +corr)',figsize=(6,4),x='Rooms',y='Price',marker='+')


# In[ ]:
