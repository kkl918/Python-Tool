import numpy as np
import requests
import pandas as pd
from bs4 import BeautifulSoup

#------------------------------------------------------------------------------
ds_path = '/home/kk/Desktop/ds/'
#------------------------------------------------------------------------------

res = requests.get('http://search.books.com.tw/search/query/key/python/cat/all')
#print(res.text)
soup = BeautifulSoup(res.text,'html.parser')


#------------------------------------------------------------------------------
#get book name, alt is var. stored book name, ex:alt="精通 Python：運用簡單的套件進行現代運算"
books = pd.Series()
for book in soup.select("img[class='itemcov']"):
 books = books.append(pd.Series([book['alt']])).reset_index(drop=True)

#------------------------------------------------------------------------------
#get prices
i = 0

prices = pd.Series()
for price in soup.select("span[class='price']"):
  if(i<books.size):
    if(len(price.select('b'))==1): #只有價格，len回傳裡面有幾個東西，EX:[<b>299</b>] -> 1個東西，price.select('b')[0] -> 取第一個
      prices = prices.append(pd.Series([price.select('b')[0].string])).reset_index(drop=True) # .string取tag<b>中的文字內容
    elif(len(price.select('b'))==2): #有打折數+價格，EX:[<b> 79</b>, <b>616</b>] -> 2個東西，price.select('b')[1] -> 取第二個
      prices = prices.append(pd.Series([price.select('b')[1].string])).reset_index(drop=True) # .string取tag<b>中的文字內容
    else:
      break
i+=1
#------------------------------------------------------------------------------
df = pd.DataFrame({'bookname':books,'price': prices})
#output = df[['bookname']]
#print(output) 


#------------------------------------------------------------------------------
#df.to_csv(r'/home/kk/Desktop/ds/req_get.csv',sep='\t',encoding='utf-8')
df.to_csv(ds_path+'get.csv',sep='\t',encoding='utf-8')
#------------------------------------------------------------------------------
