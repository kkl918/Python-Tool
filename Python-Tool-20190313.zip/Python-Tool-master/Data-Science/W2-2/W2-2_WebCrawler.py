import requests
res= requests.get("http://search.books.com.tw/search/query/key/python/cat/all")
print (res.text)

#爬標題
from bs4 import BeautifulSoup
soup = BeautifulSoup(res.text,'html.parser')
print(soup.title.string)

#爬書名
import pandas as pd
books = pd.Series()
for book in soup.select("img[class='itemcov']"):
   #加到pd.Series
   books = books.append(pd.Series([book['alt']])).reset_index(drop=True)

  
 
i = 0
prices = pd.Series()
for price in soup.select("span[class='price']"):
    if(i<books.size):
        if(len(price.select('b'))==1): #只有價格
            prices = prices.append(pd.Series([price.select('b')[0].string])).reset_index(drop=True) # .string取tag<b>中的文字內容
		elif(len(price.select('b'))==2): #有打折數+價格
            prices = prices.append(pd.Series([price.select('b')[1].string])).reset_index(drop=True) # .string取tag<b>中的文字內容
        else:
            break
		
    i+=1
   
#合併成DataFrame
df = pd.DataFrame({'書名':books,'價格':prices})
df[['書名','價格']]
