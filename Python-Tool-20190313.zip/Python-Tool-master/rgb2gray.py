import cv2, os, shutil, pathlib

py_path = os.path.dirname(os.path.realpath(__file__))
os.chdir(py_path) 

path     = r"C:\Users\kakin\Desktop\NCKU\bio-diesel_600_raw"

img_path = r"C:\Users\kakin\Desktop\p0001.tif"
out_path = r"C:\Users\kakin\Desktop\p0001_test.tif"

# change name with add _gray
def rgb2gray(image):
    img = cv2.imread(image)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(image[:-4]+'_gray'+image[-4:],gray)
    

def rgb2gray_local(image,new):
    print(os.path.join(new,image))
    #img = cv2.imread(image)
    #gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    #cv2.imwrite(os.path.join(new,image),gray)    
    
def rgb2gray(image, path):
    img = cv2.imread(image)
    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    cv2.imwrite(path, gray)
    print("Dealing with:" + image)

    
def excute_rgb2gray_local():
    new_folder = os.path.join(py_path,"new")
    pathlib.Path(new_folder).mkdir(parents=True, exist_ok=1)
    for item in os.listdir(os.getcwd()):
        if os.path.isfile(item) and item.endswith('tif'):
            img = cv2.imread(item)
            gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
            new  = item[:-4]+'_'+item[-4:]
            cv2.imwrite(new, gray)   
    for item in os.listdir(os.getcwd()):
        if os.path.isfile(item) and item.endswith('tif') and item[-5] == '_':
            shutil.move(item, new_folder)
            
            
def main():
    i=0
    for item in os.listdir(path):
        if os.path.isfile(os.path.join(path,item)) and int(item[1:-4]) % 50 == 0:
            i+=1
            # file which will be moved
            file = os.path.join(path,item)
            
            # create new folder for files and move
            new_folder = os.path.join(path,"new")
            pathlib.Path(new_folder).mkdir(parents=True, exist_ok=1)
            
            # old
            #shutil.copy(file,new_folder)
            #print(i,'\t',file)
            
            #print(file,'\t',os.path.join(new_folder,item))        
            rgb2gray(file, os.path.join(new_folder,item))


    new_folder = os.path.join(path,"new")
    pathlib.Path(new_folder).mkdir(parents=True, exist_ok=1)
    first_one = os.path.join(path,os.listdir(path)[1])
    first_dst = os.path.join(new_folder,os.listdir(path)[1])

    last_one  = os.path.join(path,os.listdir(path)[-1])
    last_dst  = os.path.join(new_folder,os.listdir(path)[-1])


    rgb2gray(first_one, first_dst)
    rgb2gray(last_one , last_dst)
    #shutil.copy(first_one,new_folder)
    #shutil.copy(last_one ,new_folder)

excute_rgb2gray_local()
